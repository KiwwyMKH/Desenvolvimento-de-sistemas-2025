import tkinter as tk

# Função que é chamada quando um botão é pressionado
def pressionar_botao(valor):
    texto_atual = visor.get()
    visor.delete(0, tk.END)
    visor.insert(0, texto_atual + str(valor))

# Função para realizar o cálculo
def calcular():
    try:
        resultado = eval(visor.get())
        visor.delete(0, tk.END)
        visor.insert(0, resultado)
    except Exception as e:
        visor.delete(0, tk.END)
        visor.insert(0, "Erro")

# Função para limpar o visor
def limpar():
    visor.delete(0, tk.END)

# Criar a janela principal
janela = tk.Tk()
janela.title("Calculadora")

# Criar o visor
visor = tk.Entry(janela, width=20, font=("Arial", 24), borderwidth=2, relief="solid", justify="right")
visor.grid(row=0, column=0, columnspan=4)

# Criar os botões
botao_1 = tk.Button(janela, text="1", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(1))
botao_2 = tk.Button(janela, text="2", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(2))
botao_3 = tk.Button(janela, text="3", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(3))
botao_4 = tk.Button(janela, text="4", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(4))
botao_5 = tk.Button(janela, text="5", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(5))
botao_6 = tk.Button(janela, text="6", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(6))
botao_7 = tk.Button(janela, text="7", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(7))
botao_8 = tk.Button(janela, text="8", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(8))
botao_9 = tk.Button(janela, text="9", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(9))
botao_0 = tk.Button(janela, text="0", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao(0))

botao_soma = tk.Button(janela, text="+", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao("+"))
botao_subtracao = tk.Button(janela, text="-", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao("-"))
botao_multiplicacao = tk.Button(janela, text="*", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao("*"))
botao_divisao = tk.Button(janela, text="/", width=5, height=2, font=("Arial", 18), command=lambda: pressionar_botao("/"))

botao_igual = tk.Button(janela, text="=", width=5, height=2, font=("Arial", 18), command=calcular)
botao_limpar = tk.Button(janela, text="C", width=5, height=2, font=("Arial", 18), command=limpar)

# Organizar os botões na tela usando grid
botao_1.grid(row=1, column=0)
botao_2.grid(row=1, column=1)
botao_3.grid(row=1, column=2)
botao_soma.grid(row=1, column=3)

botao_4.grid(row=2, column=0)
botao_5.grid(row=2, column=1)
botao_6.grid(row=2, column=2)
botao_subtracao.grid(row=2, column=3)

botao_7.grid(row=3, column=0)
botao_8.grid(row=3, column=1)
botao_9.grid(row=3, column=2)
botao_multiplicacao.grid(row=3, column=3)

botao_0.grid(row=4, column=0)
botao_limpar.grid(row=4, column=1)
botao_igual.grid(row=4, column=2)
botao_divisao.grid(row=4, column=3)

# Iniciar a aplicação
janela.mainloop()
