# main.py
from transacao import Transacao
from controleFinanceiro import ControleFinanceiro

opc = 0
meu_Gerenciador = ControleFinanceiro()

while opc != 3:
    print("\n*********** Controle de Transações ***********")
    print("1 - Cadastrar nova transação")
    print("2 - Listar transações cadastradas")
    print("3 - Sair")
    opc = int(input("Escolha uma das operações acima: "))

    if opc == 1:
        descricao = input("Forneça uma descrição da nova transação: ")
        valor = float(input("Informe o valor da transação: "))
        tipo = input("Tipo da transação (Receita/Despesa): ")
        movimentacao = Transacao(descricao, valor, tipo)
        meu_Gerenciador.adicionaTransacao(movimentacao)

    elif opc == 2:
        meu_Gerenciador.listarTransacoes()
